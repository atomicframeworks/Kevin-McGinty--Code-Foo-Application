//Set the elements style for % or auto
function squishThis(element) {
	//Grab element
	element = document.getElementById('mothership');
	//If element is compressed then unsquish
	if (element.style.overflow == 'auto') {
		element.style.overflow = '';
		element.style.height = 'auto';
	}
	else {
		//Otherwise compress
		element.style.overflow = 'auto';
		element.style.height = '80%';
	}
};

//Swap checkbox styles and status
function swapThis(checkbox){
	//Ensure we have form
	if(checkbox.type == 'checkbox') {
		//checkbox is not a form... get parent form
		var form = checkbox.parentNode;
	}
	else {
		//checkbox is a valid form
		var form = checkbox;
	}
	//Show enabled
	if (form.className == 'red' ) {
		//form.background = '#d9ead3';
		form.className = 'green';
		form[0].checked = true;
	}
	else {
	//or show disabled
		form.className = 'red';
		form[0].checked = false;
	}
}

//Here we define what is actually a win. For our purposes it's covering the board
//Our destination goal's y must = 0 
function testWin(knight) {
	
	//find x y
	var i = knight.options.yPos;
	var d = knight.options.xPos;
	
	//Knight has reached the north side of board
	//WIN
	if (parseInt(i)<=0){
		var winString = 'Wow only '+knight.options.totalMoves+' moves to cover the board? You win a shiny new penny!';
		alert(winString);
	}
}

//Build and return the HTML for our graph
function craftGraph(knight) {
		
		//Set total squares covered
		totalSquaresCovered = knight.options.xMoves+knight.options.yMoves
		
		//Find y percentage of total squares covered
		yBar = (knight.options.yMoves / totalSquaresCovered) * 100
		
		//Chop off extra decimals. Ensure we have int
		yBar = parseInt(String(yBar).substring(0,5));
		
		//Find x percentage of total squares covered
		xBar = (knight.options.xMoves / totalSquaresCovered) * 100
		
		//Chop off extra decimals. Ensure we have int
		xBar = parseInt(String(xBar).substring(0,5));
		
	
		//Wow this is ugly but I don't know a better way to format large html strings in javascript
		//We build our table here using the %'s and move counts to fill in the CSS style and data
		//The bars will fill their parent based on their % - This allows our graph to be dynamic
		var table = '<center style="color:white">GRAPH</center><table style="width:100%">'
		var t1 = '<tr> <td class="barlabel">Total Legal Moves:</td> <td class="bar">100%<br/>  <div style="width:100%">'+knight.options.totalMoves+'</div> </td> </tr>'
		
		var t2 = '<tr> <td class="barlabel">Total crossed squares:</td> <td class="bar">100%<br/> <div style="width:100%">'+totalSquaresCovered+'</div> </td> </tr>'
		
		var t3 = '<tr> <td class="barlabel">Vertical squares crossed:</td> <td class="bar">'+yBar+'% <div style="width:'+yBar+'%"> '+knight.options.yMoves+'</div> </td> </tr>'
		
		var t4 = '<tr> <td class="barlabel">Horizontal squares crossed:</td> <td class="bar">'+xBar+'% <div style="width:'+xBar+'%"> '+knight.options.xMoves+'</div> </td> </tr>'
		var html = table+t1+t2+t3+t4+'</table> '
		
		//Grab table holding element
		box = document.getElementById('graphbox');
		//Insert html table to element
		box.innerHTML = html
}


//Onclick function for square
function toggleSquare(square) {

//They clicked on square occupied by knight
	if (square.occupied != false) {
		
		//Grab the knight
		var knight = document.getElementById(square.id+"knight");
		
		//Lock our square
		square.square.options.locked = true;
		
		//testWin before moving the knight
		testWin(knight.horse);
		
		//Show graph of current knight
		craftGraph(knight.horse);
		
		//Show possible moves
		makeMoves(knight.horse,square);
		
		//Give our square the knight
		square.knight = knight.horse;
		
		//Remove previous possible moves from parent square
		//...now say that 5 times fast!
		square.square.options.parentSquare.removeFriends()
		
		//Set us up the options
		var options = {};
		if (options){
			//IE doesnt like this style
			options.yPos = square.id[0];
			options.xPos = square.id[1];
			//... so test
			if (!options.yPos || !options.xPos) {
				var id = square.id;
				options.yPos = id.substring(0,1);
				options.xPos = id.substring(1,2);
			}
		}
		//Our options now reflect current x and y position	
		
		//Updates are done unlock our friend
		square.square.options.locked = false;
		
		//Why click twice? No need.
		square.onclick = function () {};	
	}
//Square clicked with no knight currently on it
	else {
		
		//Lock board by removing onclicks
		lockBoard('boardbox');
		
		//Set occupied & change class
		square.occupy();
		
		//Make a div in the square for the horse
		square.setHorse();
		
		////Make a new horse options object for our square id
		var options = {};
		
		//IE doesnt like this style...
		options.yPos = square.id[0];
		options.xPos = square.id[1];
		//...so test and make sure we have correct position
		if (!options.yPos || !options.xPos) {
			var id = square.id;
			//alert(id.substring(0,1));
			options.yPos = id.substring(0,1);
			options.xPos = id.substring(1,2);
		}
		//The horses x y position is now set in options
		
		//Make a new horse using options
		var knighta = new Horse(square.id+'knight',options);
		
		//Test for win on first click? Gasp-- You cheaters ;D I wont tell anyone
		testWin(knighta);
		
		//Give our square the knight
		square.knight = knighta;
		
		//Set clicked square onclick to remove possible knight moves
		//Simulates "picking back up" the first horse place
		square.onclick = square.removeFriends;
		
		//Display our first graph
		//Isnt much because this is move 0 - The starting position
		craftGraph(square.knight);
		
		//Show possible moves from knight position
		makeMoves(square.knight,square);
		
		
		
		//set current player
		square.className = 'squarePlayer';
		//testWin(square);
	}
}

//Lock the onclicks
//User has placed a knight. They cannot place a new one until clearing board.
function lockBoard(boxID){
	
	//Get board element
	var board = document.getElementById(boxID);
	
	//Loop through matrix
	for (i=0; i<board.matrix.length;i++){
		for (ii=0; ii<board.matrix[i].length;ii++) {
			//Kill the onclick
			board.matrix[i][ii].element.onclick = "";
		}
	}
}

//Move the knight with an option set
function makeMoves(knight,square){
	//Create array of option sets for each possible move from knights position
	var fate = decideFate(knight);
	////Move it
		for (i=0;i<fate.length;i++){
			knight.move(fate[i],square);
		}
}

//Set the knight to Luke AutoWalker - Walk to top of chessboard
function autoHorse(knight){
	knight.options.auto = true;
}

//Grab true/false from auto checkbox. Returns true or false
function autoTest(){
	var autoStatus = document.getElementById("auto").checked
	return autoStatus;
}
//Grab true/false from display checkbox. Returns true or false
function displayTest(){
	var displayStatus = document.getElementById("display").checked
	return displayStatus;
}


//Create array of option sets for each possible move from a knights position
function decideFate(knight) {
	////Below are moves forward
	
	//Array plz
	var fate = [];
	////Hardcode here yikes! 	
	if (knight.options){
	//
	  //
	  //
	var moveOne = {};
		moveOne.yPos = parseInt(knight.options.yPos) - 2;
		moveOne.xPos = parseInt(knight.options.xPos) - 1;
		moveOne.yMoves = parseInt(knight.options.yMoves) + 2;
		moveOne.xMoves = parseInt(knight.options.xMoves) + 1;
		moveOne.totalMoves = knight.options.totalMoves + 1
	fate[0] = moveOne;
	//alert(fate[0].yPos);
	//alert(fate[0].xPos);
	
	   //
	//
	//
	var moveTwo = {};
		moveTwo.yPos = parseInt(knight.options.yPos) - 2;
		moveTwo.xPos = parseInt(knight.options.xPos) + 1;
		moveTwo.yMoves = parseInt(knight.options.yMoves) + 2;
		moveTwo.xMoves = parseInt(knight.options.xMoves) + 1;
		moveTwo.totalMoves = knight.options.totalMoves + 1
	fate[1] = moveTwo;
	
 ////	
	//
	var moveThree = {};
		moveThree.yPos = parseInt(knight.options.yPos) - 1;
		moveThree.xPos = parseInt(knight.options.xPos) - 2;
		moveThree.yMoves = parseInt(knight.options.yMoves) + 1;
		moveThree.xMoves = parseInt(knight.options.xMoves) + 2;
		moveThree.totalMoves = knight.options.totalMoves + 1
	fate[2] = moveThree;
	  ////
	//
	var moveFour = {};
		moveFour.yPos = parseInt(knight.options.yPos) - 1;
		moveFour.xPos = parseInt(knight.options.xPos) + 2;
		moveFour.yMoves = parseInt(knight.options.yMoves) + 1;
		moveFour.xMoves = parseInt(knight.options.xMoves) + 2;
		moveFour.totalMoves = knight.options.totalMoves + 1
	fate[3] = moveFour;	
	
	////Below are moves "backward"
	//Moving forward on auto has no use
	if (!autoTest()){
		//
		//
		  //
		var moveFive = {};
			moveFive.yPos = parseInt(knight.options.yPos) + 2;
			moveFive.xPos = parseInt(knight.options.xPos) + 1;
			moveFive.xMoves = parseInt(knight.options.xMoves) + 1;
			moveFive.yMoves = parseInt(knight.options.yMoves) + 2;
			moveFive.totalMoves = knight.options.totalMoves + 1
			
		fate[4] = moveFive;
		
		//
		//
	  //
		var moveSix = {};
			moveSix.yPos = parseInt(knight.options.yPos) + 2;
			moveSix.xPos = parseInt(knight.options.xPos) - 1;
			moveSix.xMoves = parseInt(knight.options.xMoves) + 1;
			moveSix.yMoves = parseInt(knight.options.yMoves) + 2;
			moveSix.totalMoves = knight.options.totalMoves + 1
			
		fate[5] = moveSix;
		
		//
		  ////
		var moveSeven = {};
			moveSeven.yPos = parseInt(knight.options.yPos) + 1;
			moveSeven.xPos = parseInt(knight.options.xPos) + 2;
			moveSeven.xMoves = parseInt(knight.options.xMoves) + 2;
			moveSeven.yMoves = parseInt(knight.options.yMoves) + 1;
			moveSeven.totalMoves = knight.options.totalMoves + 1
			
		fate[6] = moveSeven;
		
		//
	////	
		var moveEight = {};
			moveEight.yPos = parseInt(knight.options.yPos) + 1;
			moveEight.xPos = parseInt(knight.options.xPos) - 2;
			moveEight.xMoves = parseInt(knight.options.xMoves) + 2;
			moveEight.yMoves = parseInt(knight.options.yMoves) + 1;
			moveEight.totalMoves = knight.options.totalMoves + 1
			
		fate[7] = moveEight;
		}
	}
	return fate
}