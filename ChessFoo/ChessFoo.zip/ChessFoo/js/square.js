//Constructor for a square on the chess board
function Square(elementName, options) {
	
	//Give the square our element
	this.element = document.getElementById(elementName);
	
	//Errors
	if (!this.element) throw new Error(elementName + ' not found' );
	
	//Give the element our square
	this.element.square = this;
	
	//If no options were passed
	this.options = options || {};
	
	//Set us up the options
	if (options) {
		
		//Occupied status
		this.options.occupied = options.occupied || false;
		
		//Incase we want to pass onclick function ref
		this.options.onClick = options.onClick || function() {};
		
		//CSS Options
		this.options.occupiedClassName = 
			options.occupiedClassName || this.CLASS_DEFAULT_OCCUPIED;
		this.options.unoccupiedClassName =
			options.unoccupiedClassName || this.CLASS_DEFAULT_UNOCCUPIED;
	}
	
	//Mouse function events
	this.element.onclick = this.ONCLICK;
	
	//Methods
	//Set occupied to true and change CSS
	this.element.occupy = this.occupy;
	//Set occupied to true and change CSS
	this.element.unoccupy = this.unoccupy;
	
	//Place a knight div in the square
	this.element.setHorse = this.setHorse;
	//Remove the knight div from the square
	this.element.removeHorse = this.removeHorse;
	
	//Remove all friend squares. These are possible moves
	this.element.removeFriends = this.removeFriends;
	
	
	//Set square occupied status
	if (this.options.occupied == true ) {
		this.occupy();
	}
	else {
		this.unoccupy();
	}
}

//Remove possible moves from previous position
//Used when moving squares
Square.prototype.removeFriends = function () {
	
	//If no current square or knight we have a problem...
	if (!this || !this.knight){return;}
	
	//set the knights x and y
	//IE doesnt like this style... 
	this.knight.options.yPos = this.id[0];
	this.knight.options.xPos = this.id[1];
		
		//...so test and set properly
		if (!this.knight.options.yPos || !this.knight.options.xPos) {
			var id = this.id;
			this.knight.options.yPos = id.substring(0,1);
			this.knight.options.xPos = id.substring(1,2);
		}
	// x y options are now set on knight
	
	//Grab option set for all possible moves
	var fate = decideFate(this.knight);
	////For each fate remove the knight!
		for (i=0;i<fate.length;i++){
			
			//Grab xy of new  element position
			var xPos = fate[i].xPos;
			var yPos = fate[i].yPos;
			
			//Make SURE we have a string
			var squareNum = String(yPos)+String(xPos);
			
			//Get the new element
			elem = document.getElementById(squareNum)
			
			//Error test
			if (elem != null) {
				//Dont operate on locked squares
				if(elem.square.id == undefined && elem.square.options.locked != true) {
					
					//Set unoccupied and change CSS
					elem.square.unoccupy();
					
					//Remove the knight
					elem.square.knight = null;
					
					//Kill the knight div in the square
					elem.square.removeHorse();
				}
				if (elem.square.options.locked == true) {
					//Oh look this is the clicked square
					//That is why it is locked
					
					////Lets set this off with a highlight( by swapping CSS ) so we can tell our current square
					
					elem.square.element.className = 'squarePlayer';
					
					
					elem.square.element.toured = true;
					//elem.square.element.className = 'squareBurned';
					elem.style.background = "url(images/mediumRedMarble.jpg)";
					
					//elem.square.element.style.background = 'red' ;//
					
					//elem.square.element.className = 'squareBurned';
				}
			}
		}
	

	//Done with the fates
	//If no parent this is the first square. Kill on click
	if (this.square.options.parentSquare == undefined){
		
		//Set unoccupied and change CSS
		this.square.unoccupy();
		
		////Delete horse div
		this.square.removeHorse();
	}
	//Reset onclick
	this.onclick = this.square.ONCLICK;
}

//Function constant used if an onclick handler is specified. We are specifiing toggleSquare(square) when we create a  new square
Square.prototype.ONCLICK = function () {
	this.square.options.onClick(this);
}

//CSS class constant (defaults)
Square.prototype.CLASS_DEFAULT_UNOCCUPIED = 'squareUnoccupied';
Square.prototype.CLASS_DEFAULT_OCCUPIED = 'squareOccupied';
Square.prototype.CLASS_DEFAULT_PRESSED = 'squarePressed';
Square.prototype.CLASS_DEFAULT_ARMED = 'squareArmed';


////Class Constant (defaults) Methods
//

//Occupy function
//Set occupied true and change CSS
Square.prototype.occupy = function () {
	this.square.element.occupied = true;
	this.className = this.square.options.occupiedClassName;
}

//Unoccupy function
//Set occupied false and change CSS
Square.prototype.unoccupy = function () {
	// This happens booting up the board 
	if (!this.square) {
		this.element.occupied = false;
		this.element.className = this.options.unoccupiedClassName;
		}
	else {
		//After startup normally here
		this.square.element.occupied = false;
		this.className = this.square.options.unoccupiedClassName;
	}
}

//Insert a centered horse div inside element
Square.prototype.setHorse = function () {
	this.innerHTML += "<center><div id='"+ this.id +"knight'><!--IGN--></div></center>"
}

//Remove the horse div from the square
Square.prototype.removeHorse = function () {
	
	if (!this.element){
		//This happens clearing the board
		this.innerHTML = this.id;
	}
	else {
		//Otherwise set id as html. This is the square number		
		this.element.innerHTML = this.element.id;
	}
}
