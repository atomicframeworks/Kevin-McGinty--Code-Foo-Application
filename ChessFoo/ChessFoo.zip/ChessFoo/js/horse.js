
//Create a horse object on elementName using options
function Horse(elementName, options) {
	
	//Find the element
	this.element = document.getElementById(elementName);
	
	//Error display
	if (!this.element) throw new Error(elementName + ' not found' );
	
	//attach the horse object to the element
	this.element.horse = this;
	//Our options = the passed options // if none then new object
	this.options = options || {};
		
		//Set us up the options or the defaults
		if (options) {
			//Horse position
			this.options.xPos = options.xPos || 0;
			this.options.yPos = options.yPos || 0;
			//Horse move count
			this.options.xMoves = options.xMoves || 0;
			this.options.yMoves = options.yMoves || 0;
			this.options.totalMoves = options.totalMoves || 0;
		}
	//attach move method to the element
	this.element.move = this.move;
	//this.element.onclick = this.element.move;
	//this.element.onclick = this.move;
	this.element.style.background = '';
	
	//Stick in a horse image
	this.element.innerHTML = '<img class="horse" src="images/smallHorse.png"></img>';
	
	
	//String to display our total moves moves along the y axis and moves along the x axis
	var totalMoves =  "m"+this.options.totalMoves+"y"+String(this.options.yMoves)+"x"+String(this.options.xMoves);
	
	////Uncomment to show moves instead of image
	//Test to see if we want move numbers displayed instead of image
	if(displayTest()){
		this.element.innerHTML = totalMoves;
	}
}


//Horse move method. Creates a new horse with the passed option set. Attaches square as the parent
Horse.prototype.move = function (options,square) {
	//Error trap just in case
	if (!this.element) throw new Error(elementName + ' not found' );
	
	//options are optional 
	this.options = options || {};
			
		//Set us up the options
		//options will = new passed option set or if undefined then the current elements option value
		if (options) {
			//Horse position 
			this.element.horse.options.xPos =
				options.xPos || this.element.horse.options.xPos;
			this.element.horse.options.yPos = 
				options.yPos || this.element.horse.options.yPos;
			//Horse move count
			this.element.horse.options.xMoves = 
				options.xMoves || this.element.horse.options.xMoves;
			this.element.horse.options.yMoves =
				options.yMoves || this.element.horse.options.yMoves;
			this.element.horse.options.totalMoves =
				options.totalMoves || this.element.horse.options.totalMoves;
			//Parent square to see where we are coming from
			this.element.horse.options.parentSquare = 
				options.parentSquare || this.element.horse.options.parentSquare;
		}
		
		//Convert our new options to xy string for element id
		goalNumber = String(this.element.horse.options.yPos) + String(this.element.horse.options.xPos)
		//Grab goal element to move to
		goal = document.getElementById(goalNumber);
		//No goal? No problem.
		if (goal == null) return;
		
		//If there is a parent square add to options
		if (square){
			goal.square.options.parentSquare = square;
		}
		
		////The square is goal
		//set occupied status and change CSS
		goal.occupy();
		//create a knight div
		goal.setHorse();
		//Create a new knight for that div
		var knight = new Horse(goalNumber+'knight',options);
		//alert(goal.id);
		
		//Set the goal onclick to onclick option of square
		goal.onclick = function () {this.square.options.onClick(this)}
		
		//Toggle the goal to pick up the figure and place it again
		if(autoTest()){
		
			////LUKE AUTO WALKER
			//fate = decideFate(knight);
			//throwBones(knight,fate)
			//alert('new move');
			setTimeout('toggleSquare(goal)', 500)
			//setTimeout ( , 20000 );
		}
}


