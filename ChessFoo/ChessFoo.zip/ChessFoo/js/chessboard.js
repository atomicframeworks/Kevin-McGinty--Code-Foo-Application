
// 8x8 matrix chess board for visual representation 
// Unused 
var boardMatrix = [
	[00, 01, 02, 03, 04, 05, 06, 07],
	[10, 11, 12, 13, 14, 15, 16, 17],
	[20, 21, 22, 23, 24, 25, 26, 27],
	[30, 31, 32, 33, 34, 35, 36, 37],
	[40, 41, 42, 43, 44, 45, 46, 47],
	[50, 51, 52, 53, 54, 55, 56, 57],
	[60, 61, 62, 63, 64, 65, 66, 67],
	[70, 71, 72, 73, 74, 75, 76, 77]
]

//Our matrix is an array of arrays of objects...

//Function returns an empty y by x matrix
function makeGrid(x,y) {
	var matrix = [];
	var a
	for (i=0; i<y;i++){
		a = []
		for (ii=0; ii<x;ii++) {
			
			a[ii] = {};
			//a[ii] = new Square(String(i)+String(ii), { onClick:toggleSquare});
		}
		matrix[i] = a;
	}
return matrix;
}

//Create a div for each item in matrix
function drawDivs(elementName,matrix){
	//Container
	var html="<div id='boardboarder'>";
	for (i=0; i<matrix.length;i++){
		for (ii=0; ii<matrix[i].length;ii++) {
			//Add a new div to html
			html += '<div id="'+[i]+[ii]+'">'+[i]+[ii]+'</div>'	
		}
	}
	var box = document.getElementById(elementName);
	//Close the container
	box.matrix = matrix;
	//alert(box.id)
	box.innerHTML = html+"</div>";
}

//Create a square for each item in the matrix
function populateMatrix(matrix){
	for (i=0; i<matrix.length;i++){
		for (ii=0; ii<matrix[i].length;ii++) {
			//Create a new Square that instruments the div element in matrix
			//Stuff it in our matrix
			matrix[i][ii] = new Square(String(i)+String(ii), { onClick:toggleSquare});
			//Check if square is even or odd for correct square color on the board
			//White
			if ( isEven(i+ii) ) {			
				newImage = "url(images/mediumGreyMarble.jpg)";				
				matrix[i][ii].element.style.backgroundImage = newImage;
				//matrix[i][ii].element.style.background = "white";
			}
			//Black
			else {
				newImage = "url(images/mediumBlackMarble.jpg)"
				matrix[i][ii].element.style.backgroundImage = newImage;
			}	
		}
	}
}

//Check if even. 0 also returns even
//Returns true if even
var isEven = function(someNumber){
//alert(someNumber);
    if (someNumber == 0) {
		return true;
	}
	return (someNumber%2 == 0) ? true : false;
}

//Loop through matrix and reset the squares
function clearMatrix(matrix){
	for (i=0; i<matrix.length;i++){
		for (ii=0; ii<matrix[i].length;ii++) {
			//Set status to unoccupied and change class
			matrix[i][ii].element.unoccupy();
			//remove the horse div
			matrix[i][ii].element.removeHorse();
			//reset the onclick
			//alert('matrix '+[i]+' '+[ii]+':'+matrix[i][ii].element.id);
			matrix[i][ii].element.onclick = function (){this.square.options.onClick(this);}
		}
	}
}








