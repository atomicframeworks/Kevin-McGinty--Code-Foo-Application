//Set the elements style for % or auto
function squishThis(element) {
	//Grab element
	element = document.getElementById('mothership');
	//If element is compressed then unsquish
	if (element.style.overflow == 'auto') {
		element.style.overflow = '';
		element.style.height = 'auto';
	}
	else {
		//Otherwise compress
		element.style.overflow = 'auto';
		element.style.height = '80%';
	}
};

//Swap checkbox styles and status
function swapThis(checkbox){
	//Ensure we have form
	if(checkbox.type == 'checkbox') {
		//checkbox is not a form... get parent form
		var form = checkbox.parentNode;
	}
	else {
		//checkbox is a valid form
		var form = checkbox;
	}
	//Show enabled
	if (form.className == 'red' ) {
		//form.background = '#d9ead3';
		form.className = 'green';
		form[0].checked = true;
	}
	else {
	//or show disabled
		form.className = 'red';
		form[0].checked = false;
	}
}



//Build and return the HTML for our graph
function craftGraph(knight) {
		
		//Set total squares covered
		totalSquaresCovered = knight.options.xMoves+knight.options.yMoves
		
		//Find y percentage of total squares covered
		yBar = (knight.options.yMoves / totalSquaresCovered) * 100
		
		//Chop off extra decimals. Ensure we have int
		yBar = parseInt(String(yBar).substring(0,5));
		
		//Find x percentage of total squares covered
		xBar = (knight.options.xMoves / totalSquaresCovered) * 100
		
		//Chop off extra decimals. Ensure we have int
		xBar = parseInt(String(xBar).substring(0,5));
		
	
		//Wow this is ugly but I don't know a better way to format large html strings in javascript
		//We build our table here using the %'s and move counts to fill in the CSS style and data
		//The bars will fill their parent based on their % - This allows our graph to be dynamic
		var table = '<center style="color:white">GRAPH</center><table style="width:100%">'
		var t1 = '<tr> <td class="barlabel">Total Legal Moves:</td> <td class="bar">100%<br/>  <div style="width:100%">'+knight.options.totalMoves+'</div> </td> </tr>'
		
		var t2 = '<tr> <td class="barlabel">Total crossed squares:</td> <td class="bar">100%<br/> <div style="width:100%">'+totalSquaresCovered+'</div> </td> </tr>'
		
		var t3 = '<tr> <td class="barlabel">Vertical squares crossed:</td> <td class="bar">'+yBar+'% <div style="width:'+yBar+'%"> '+knight.options.yMoves+'</div> </td> </tr>'
		
		var t4 = '<tr> <td class="barlabel">Horizontal squares crossed:</td> <td class="bar">'+xBar+'% <div style="width:'+xBar+'%"> '+knight.options.xMoves+'</div> </td> </tr>'
		var html = table+t1+t2+t3+t4+'</table> '
		
		//Grab table holding element
		box = document.getElementById('graphbox');
		//Insert html table to element
		box.innerHTML = html
}


//Onclick function for square
function toggleSquare(square) {

//They clicked on square occupied by knight
	if (square.occupied != false) {
		
		//Grab the knight
		var knight = document.getElementById(square.id+"knight");
		
		//Lock our square
		square.square.options.locked = true;
				
		//Show graph of current knight
		craftGraph(knight.horse);
		
		//Show possible moves
		makeMoves(knight.horse,square);
		
		//Give our square the knight
		square.knight = knight.horse;
		
		//Remove parents previous possible moves
		//...now say that 5 times fast!
		//
		//No need to remove friends when we are divining the moves
		
	
			//alert(square.square.options.win)
			square.square.options.parentSquare.removeFriends()
			//clear the final square as well
			if (square.fates == 0) {
				square.removeFriends();
			}
			//square.removeFriends()
		
		//Set us up the options
		var options = {};
		if (options){
			//IE doesnt like this style
			options.yPos = square.id[0];
			options.xPos = square.id[1];
			//... so test
			if (!options.yPos || !options.xPos) {
				var id = square.id;
				options.yPos = id.substring(0,1);
				options.xPos = id.substring(1,2);
			}
		}
		//Our options now reflect current x and y position	
		
		//Updates are done unlock our friend
		square.square.options.locked = false;
		
		/////Removed and still works fine...
		//square.style.background = "url(images/mediumRedMarble.jpg)";
		
		//square.toured = true;
		//square.className = 'squareBurned';
		
		//Why click twice? No need.
		square.onclick = function () {};
		////LUKE AUTO WALKER
		// if autoTest()
		//fate = decideFate(square.knight);
		//alert('new fate:'+fate.length);
		
	}
//Square clicked with no knight currently on it
	else {
		
		//Lock board by removing onclicks
		lockBoard('boardbox');
		
		//Set occupied & change class
		square.occupy();
		
		//Make a div in the square for the horse
		square.setHorse();
		
		////Make a new horse options object for our square id
		var options = {};
		
		//IE doesnt like this style...
		options.yPos = square.id[0];
		options.xPos = square.id[1];
		//...so test and make sure we have correct position
		if (!options.yPos || !options.xPos) {
			var id = square.id;
			//alert(id.substring(0,1));
			options.yPos = id.substring(0,1);
			options.xPos = id.substring(1,2);
		}
		//The horses x y position is now set in options
		
		//Make a new horse using options
		var knight = new Horse(square.id+'knight',options);
		
		//Give our square the knight
		square.knight = knight;
		
	
		
		//No take backs. Knight is down you must choose a move
		square.onclick = '';
		
		//Display our first graph
		//Isnt much because this is move 0 - The starting position
		//NaN will show for our divide by 0's hooray!
		craftGraph(square.knight);
		
		//Show possible moves from knight position
		makeMoves(square.knight,square);
		
		//set current player
		square.className = 'squarePlayer';
		
		//I think we have been here before...
		square.toured = true;
		//...So show that we have
		square.style.background = "url(images/mediumRedMarble.jpg)";
	}	
}

//Lock the onclicks
//User has placed a knight. They cannot place a new one (on unoccupied square) until clearing board.
function lockBoard(boxID){
	
	//Get board element
	var board = document.getElementById(boxID);
	
	//Loop through matrix
	for (i=0; i<board.matrix.length;i++){
		for (ii=0; ii<board.matrix[i].length;ii++) {
			//Kill the onclick
			board.matrix[i][ii].element.onclick = "";
		}
	}
}

//Move the knight with an option set
function makeMoves(knight,square){

	//If Auto-Walker
	if (autoTest()) {
		//We are looping fate arrays. So we need an array
		fate = [];
		//Determine the "one" move for our knight
		fate[0] = throwBones(knight);		
	}
	//Normally go here
	else {
		//Create array of option sets for each possible move from knights position
		var fate = decideFate(knight);
	}
	
	////Move it
	for (i=0;i<fate.length;i++){
		//alert('moving : '+fate[i].yPos+''+fate[i].xPos);
		knight.move(fate[i],square);
	}
		
		
}

//Set the knight to Luke AutoWalker - Walk to top of chessboard
function autoHorse(knight){
	knight.options.auto = true;
}

//Grab true/false from auto checkbox. Returns true or false
function autoTest(){
	var autoStatus = document.getElementById("auto").checked
	return autoStatus;
}
//Grab true/false from display checkbox. Returns true or false
function displayTest(){
	var displayStatus = document.getElementById("display").checked
	return displayStatus;
}


//Create array of option sets for each possible move from a knights position
function decideFate(knight) {
	////When Auto-Walker
	//The "newest" move set( pushed to array here) will take priority in case of a tie.
	
	//Array plz
	var fate = [];
	
	if (knight.options){
	
	////Ugly here yikes! 	
	
	   //
	//
	//
	var moveZero = {};
		moveZero.yPos = parseInt(knight.options.yPos) - 2;
		moveZero.xPos = parseInt(knight.options.xPos) + 1;
		moveZero.yMoves = parseInt(knight.options.yMoves) + 2;
		moveZero.xMoves = parseInt(knight.options.xMoves) + 1;
		moveZero.totalMoves = knight.options.totalMoves + 1
	fate[0] = moveZero;
	
	  ////
	//
	var moveOne = {};
		moveOne.yPos = parseInt(knight.options.yPos) - 1;
		moveOne.xPos = parseInt(knight.options.xPos) + 2;
		moveOne.yMoves = parseInt(knight.options.yMoves) + 1;
		moveOne.xMoves = parseInt(knight.options.xMoves) + 2;
		moveOne.totalMoves = knight.options.totalMoves + 1
	fate[1] = moveOne;	
	
	
		//
		  ////
	var moveTwo = {};
		moveTwo.yPos = parseInt(knight.options.yPos) + 1;
		moveTwo.xPos = parseInt(knight.options.xPos) + 2;
		moveTwo.xMoves = parseInt(knight.options.xMoves) + 2;
		moveTwo.yMoves = parseInt(knight.options.yMoves) + 1;
		moveTwo.totalMoves = knight.options.totalMoves + 1
	fate[2] = moveTwo;
	
		//
		//
		  //
	var moveThree = {};
		moveThree.yPos = parseInt(knight.options.yPos) + 2;
		moveThree.xPos = parseInt(knight.options.xPos) + 1;
		moveThree.xMoves = parseInt(knight.options.xMoves) + 1;
		moveThree.yMoves = parseInt(knight.options.yMoves) + 2;
		moveThree.totalMoves = knight.options.totalMoves + 1
	fate[3] = moveThree;
		
		//
		//
	  //
	var moveFour = {};
		moveFour.yPos = parseInt(knight.options.yPos) + 2;
		moveFour.xPos = parseInt(knight.options.xPos) - 1;
		moveFour.xMoves = parseInt(knight.options.xMoves) + 1;
		moveFour.yMoves = parseInt(knight.options.yMoves) + 2;
		moveFour.totalMoves = knight.options.totalMoves + 1
	fate[4] = moveFour;
		
	
	//
	 ////	
	var moveFive = {};
		moveFive.yPos = parseInt(knight.options.yPos) + 1;
		moveFive.xPos = parseInt(knight.options.xPos) - 2;
		moveFive.xMoves = parseInt(knight.options.xMoves) + 2;
		moveFive.yMoves = parseInt(knight.options.yMoves) + 1;
		moveFive.totalMoves = knight.options.totalMoves + 1
		
	
	fate[5] = moveFive;
		
		
	 ////	
	//
	var moveSix = {};
		moveSix.yPos = parseInt(knight.options.yPos) - 1;
		moveSix.xPos = parseInt(knight.options.xPos) - 2;
		moveSix.yMoves = parseInt(knight.options.yMoves) + 1;
		moveSix.xMoves = parseInt(knight.options.xMoves) + 2;
		moveSix.totalMoves = knight.options.totalMoves + 1
	fate[6] = moveSix;
	
		 //
	  //
	  //
	var moveSeven = {};
		moveSeven.yPos = parseInt(knight.options.yPos) - 2;
		moveSeven.xPos = parseInt(knight.options.xPos) - 1;
		moveSeven.yMoves = parseInt(knight.options.yMoves) + 2;
		moveSeven.xMoves = parseInt(knight.options.xMoves) + 1;
		moveSeven.totalMoves = knight.options.totalMoves + 1
	fate[7] = moveSeven;

	}
	return fate
}

//Lets keep with the fate theme
//Return the one move that the knight will make
function throwBones(knight) {
	//Get all possible moves
	fate = decideFate(knight)
	
	//Loop through possible moves fate option set
	for (i=0;i<fate.length;i++){
	
		//If fate is legal move
		if (readPalms(fate[i])) {
			//Pass fate to func 
			//Func tests possible moves from position 
			//Returns int num of possible moves
			//Attach returned possible moves to fate
			fate[i].threads = castRunes(fate[i])	
		}
	}
	
	//to hold the best fate
	var minFate = {};
	var newFate;
	//Loop fates again
	for (i=0;i<fate.length;i++){
		//Test for least possible moves
		////If the possible moves from fate[i] are less then or equal to the current lowest thread count
		//OR IF the current least thread count is undefined  (happens when we init the count)
		//Set the new lowest thread count
		if (fate[i].threads <= minFate.threads || minFate.threads == undefined){
			
			if (fate[i].threads == 0) {
				//No possible moves from square. We must take it
				return fate[i];
			}
			//Error trap - no undefined 
			if (fate[i].threads != undefined){
			
				//TIE
				if (fate[i].threads == minFate.threads) {
				
					////Currently takes 'oldest' move in our list
					////We could write a better tie breaker here
					//If we want to take the 'newest' fate uncomment below
					newFate = fate[i];
				}
				//Looks good- we drop through and return fate
				else {
					minFate.threads = fate[i].threads;
					newFate = fate[i];
				}
			}
		}
	}
	return newFate;
}

//Return number of possible moves from fate set
function castRunes(fate) {
	
	//Convert fate to new object
	//New object holder for fates
	var convert = {};
	convert.options = {};
	convert.options.yPos = fate.yPos;
	convert.options.xPos = fate.xPos;
	
	//Grab the element
	var elem = document.getElementById(String(fate.yPos)+fate.xPos);
	if (!elem) {
		//alert('no id');
		return ;
	};

	//This one has been visited. 
	if (elem.toured == true) {
		//return this as fate to display for display mode;
		return '*';
	};
	
	//Grab possible moves from fate
	var newFate = decideFate(convert);
	//Init fate counter
	var numFates = 0
	
	////For each option move set in newFate
	//Determine if move is legal
	//Add to counter
	for (r=0;r<newFate.length;r++){
		
		//Test the square to see if it is viable legal move
		//Check if the item has been toured
		if (readPalms(newFate[r]) == true) {
			//Possible move - now add to counter
			numFates += 1;
		}
		else {
			//not a spot
		}
	}
	
	//Attach the total possible moves to element
	elem.fates = numFates;
	
	//Return number of possible moves
	return numFates;
	
}

//Return true if element is legal move
//Return false if element is occupied or visited
function readPalms(options) {
	
	//Set us up the options
	if (options){
		//Find position
		var ourPosition = String(options.yPos)+options.xPos;
		//Get element by position
		var myElement = document.getElementById(ourPosition);
		
		//Error trap- for off the board items aka squares that don't exist
		if (!myElement){
			//alert('break');
			return false;
		};
		
		
		//If the element is currently occupied or has been visited return False
		if (myElement.occupied == true || myElement.toured == true) {
			return false;
		}
		//If the element is open return true
		else {
			return true;
		}
	}	
}

//Set the interval between hops
function timer(goal) {
	
	//Find by board value
	theTime = document.getElementById('seconds').value || 0;
	//We asked user for seconds so convert
	theSeconds = theTime * 1000;
	//Cool your heels knight
	setTimeout('toggleSquare(goal)', theSeconds)
}

			
			
