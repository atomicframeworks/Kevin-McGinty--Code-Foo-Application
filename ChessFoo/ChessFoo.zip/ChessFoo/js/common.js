//Set the elements style for % or auto
function squishThis(element) {
	//Grab element
	element = document.getElementById('mothership');
	//If element is compressed then unsquish
	if (element.style.overflow == 'auto') {
		element.style.overflow = '';
		element.style.height = 'auto';
	}
	else {
		//Otherwise compress
		element.style.overflow = 'auto';
		element.style.height = '80%';
	}
};

//Swap checkbox styles and status
function swapThis(checkbox){
	//Ensure we have form
	if(checkbox.type == 'checkbox') {
		//checkbox is not a form... get parent form
		var form = checkbox.parentNode;
	}
	else {
		//checkbox is a valid form
		var form = checkbox;
	}
	//Show enabled
	if (form.className == 'red' ) {
		//form.background = '#d9ead3';
		form.className = 'green';
		form[0].checked = true;
	}
	else {
	//or show disabled
		form.className = 'red';
		form[0].checked = false;
	}
}

//Here we define what is actually a win. For our purposes it's covering the board
//Our destination goal's y must = 0 
function testWin(knight) {
	
	//find x y
	var i = knight.options.yPos;
	var d = knight.options.xPos;
	var win = knight.options.win;
	if (win == 'win'){
		//alert('winnerrrrr');
		
		return
	}
	//Knight has reached the north side of board
	//WIN
	if (parseInt(i)<=0){
		var winString = 'Wow only '+knight.options.totalMoves+' moves to cover the board? You win a shiny new penny!';
		//alert(winString);
	}
}

//Build and return the HTML for our graph
function craftGraph(knight) {
		
		//Set total squares covered
		totalSquaresCovered = knight.options.xMoves+knight.options.yMoves
		
		//Find y percentage of total squares covered
		yBar = (knight.options.yMoves / totalSquaresCovered) * 100
		
		//Chop off extra decimals. Ensure we have int
		yBar = parseInt(String(yBar).substring(0,5));
		
		//Find x percentage of total squares covered
		xBar = (knight.options.xMoves / totalSquaresCovered) * 100
		
		//Chop off extra decimals. Ensure we have int
		xBar = parseInt(String(xBar).substring(0,5));
		
	
		//Wow this is ugly but I don't know a better way to format large html strings in javascript
		//We build our table here using the %'s and move counts to fill in the CSS style and data
		//The bars will fill their parent based on their % - This allows our graph to be dynamic
		var table = '<center style="color:white">GRAPH</center><table style="width:100%">'
		var t1 = '<tr> <td class="barlabel">Total Legal Moves:</td> <td class="bar">100%<br/>  <div style="width:100%">'+knight.options.totalMoves+'</div> </td> </tr>'
		
		var t2 = '<tr> <td class="barlabel">Total crossed squares:</td> <td class="bar">100%<br/> <div style="width:100%">'+totalSquaresCovered+'</div> </td> </tr>'
		
		var t3 = '<tr> <td class="barlabel">Vertical squares crossed:</td> <td class="bar">'+yBar+'% <div style="width:'+yBar+'%"> '+knight.options.yMoves+'</div> </td> </tr>'
		
		var t4 = '<tr> <td class="barlabel">Horizontal squares crossed:</td> <td class="bar">'+xBar+'% <div style="width:'+xBar+'%"> '+knight.options.xMoves+'</div> </td> </tr>'
		var html = table+t1+t2+t3+t4+'</table> '
		
		//Grab table holding element
		box = document.getElementById('graphbox');
		//Insert html table to element
		box.innerHTML = html
}


//Onclick function for square
function toggleSquare(square) {

//They clicked on square occupied by knight
	if (square.occupied != false) {
		
		//Grab the knight
		var knight = document.getElementById(square.id+"knight");
		
		//Lock our square
		square.square.options.locked = true;
		
		//alert(square.id);
		//alert('new fate: '+knight.horse.options.yPos+''+knight.horse.options.xPos);
		
		/*
		if (autoTest()) {
			knight.horse.options = throwBones(knight.horse);
			//alert('bones of new horse '+knight.horse.options.yPos+''+knight.horse.options.xPos);
		}
		*/
		
		
		//testWin before moving the knight
		testWin(knight.horse);
		
		//Show graph of current knight
		craftGraph(knight.horse);
		
		//Show possible moves
		makeMoves(knight.horse,square);
		
		//Give our square the knight
		square.knight = knight.horse;
		
		//Remove previous possible moves from parent square
		//...now say that 5 times fast!
		//
		//No need to kill friends when we are divining the moves
		if (!autoTest()) {
			square.square.options.parentSquare.removeFriends()
		}
		//Set us up the options
		var options = {};
		if (options){
			//IE doesnt like this style
			options.yPos = square.id[0];
			options.xPos = square.id[1];
			//... so test
			if (!options.yPos || !options.xPos) {
				var id = square.id;
				options.yPos = id.substring(0,1);
				options.xPos = id.substring(1,2);
			}
		}
		//Our options now reflect current x and y position	
		
		//Updates are done unlock our friend
		square.square.options.locked = false;
		//square.toured = true;
		//square.className = 'squareBurned';
		square.style.background = "url(images/mediumRedMarble.jpg)";
		
		
		
		//Why click twice? No need.
		square.onclick = function () {};
		////LUKE AUTO WALKER
		// if autoTest()
		//fate = decideFate(square.knight);
		//alert('new fate:'+fate.length);
		
	}
//Square clicked with no knight currently on it
	else {
		
		//Lock board by removing onclicks
		lockBoard('boardbox');
		
		//Set occupied & change class
		square.occupy();
		
		//Make a div in the square for the horse
		square.setHorse();
		
		////Make a new horse options object for our square id
		var options = {};
		
		//IE doesnt like this style...
		options.yPos = square.id[0];
		options.xPos = square.id[1];
		//...so test and make sure we have correct position
		if (!options.yPos || !options.xPos) {
			var id = square.id;
			//alert(id.substring(0,1));
			options.yPos = id.substring(0,1);
			options.xPos = id.substring(1,2);
		}
		//The horses x y position is now set in options
		
		//Make a new horse using options
		var knight = new Horse(square.id+'knight',options);
		
		//Test for win on first click? Gasp-- You cheaters ;D I wont tell anyone
		testWin(knight);
		
		//Give our square the knight
		square.knight = knight;
		
		////LUKE AUTO WALKER
		// if autoTest()
		//fate = decideFate(knight);
		//alert('old: '+fate.length);
		//alert('POS'+knight.options.yPos+''+knight.options.xPos);
		
		
		
		/*
		if (autoTest()) {
			knight.options = throwBones(knight);
			//alert('bones of 2nd horse '+knight.options.yPos+''+knight.options.xPos);
		}
		
		
		*/
		
		
		//Set clicked square onclick to remove possible knight moves
		//Simulates "picking back up" the first horse place
		square.onclick = square.removeFriends;
		
		//Display our first graph
		//Isnt much because this is move 0 - The starting position
		craftGraph(square.knight);
		
		//Show possible moves from knight position
		makeMoves(square.knight,square);
		
		
		
		//set current player
		square.className = 'squarePlayer';
		
		
		//var image = "url(images/mediumRedMarble.jpg)";
		square.toured = true;
		//square.className = 'squareBurned';
		square.style.background = "url(images/mediumRedMarble.jpg)";
		
		//testWin(square);
		
		
	}
	
	

	
}

//Lock the onclicks
//User has placed a knight. They cannot place a new one until clearing board.
function lockBoard(boxID){
	
	//Get board element
	var board = document.getElementById(boxID);
	
	//Loop through matrix
	for (i=0; i<board.matrix.length;i++){
		for (ii=0; ii<board.matrix[i].length;ii++) {
			//Kill the onclick
			board.matrix[i][ii].element.onclick = "";
		}
	}
}

//Move the knight with an option set
function makeMoves(knight,square){
	
	if (autoTest()) {
			fate = [];
			fate[0] = throwBones(knight);
			
			//alert('bones of 2nd horse '+fate[0].yPos+''+fate[0].xPos);
		
		}
		else {
			//Create array of option sets for each possible move from knights position
			var fate = decideFate(knight);
		}
	
	
	
	////Move it
		for (i=0;i<fate.length;i++){
		
			
			//alert('moving : '+fate[i].yPos+''+fate[i].xPos);
			knight.move(fate[i],square);
			
		}
		
		
}

//Set the knight to Luke AutoWalker - Walk to top of chessboard
function autoHorse(knight){
	knight.options.auto = true;
}

//Grab true/false from auto checkbox. Returns true or false
function autoTest(){
	var autoStatus = document.getElementById("auto").checked
	return autoStatus;
}
//Grab true/false from display checkbox. Returns true or false
function displayTest(){
	var displayStatus = document.getElementById("display").checked
	return displayStatus;
}


//Create array of option sets for each possible move from a knights position
function decideFate(knight) {
	////Below are moves forward
	
	//Array plz
	var fate = [];
	////Hardcode here yikes! 	
	if (knight.options){
	//
	  //
	  //
	var moveOne = {};
		moveOne.yPos = parseInt(knight.options.yPos) - 2;
		moveOne.xPos = parseInt(knight.options.xPos) - 1;
		moveOne.yMoves = parseInt(knight.options.yMoves) + 2;
		moveOne.xMoves = parseInt(knight.options.xMoves) + 1;
		moveOne.totalMoves = knight.options.totalMoves + 1
	fate[0] = moveOne;
	//alert(fate[0].yPos);
	//alert(fate[0].xPos);
	
	   //
	//
	//
	var moveTwo = {};
		moveTwo.yPos = parseInt(knight.options.yPos) - 2;
		moveTwo.xPos = parseInt(knight.options.xPos) + 1;
		moveTwo.yMoves = parseInt(knight.options.yMoves) + 2;
		moveTwo.xMoves = parseInt(knight.options.xMoves) + 1;
		moveTwo.totalMoves = knight.options.totalMoves + 1
	fate[1] = moveTwo;
	
 ////	
	//
	var moveThree = {};
		moveThree.yPos = parseInt(knight.options.yPos) - 1;
		moveThree.xPos = parseInt(knight.options.xPos) - 2;
		moveThree.yMoves = parseInt(knight.options.yMoves) + 1;
		moveThree.xMoves = parseInt(knight.options.xMoves) + 2;
		moveThree.totalMoves = knight.options.totalMoves + 1
	fate[2] = moveThree;
	  ////
	//
	var moveFour = {};
		moveFour.yPos = parseInt(knight.options.yPos) - 1;
		moveFour.xPos = parseInt(knight.options.xPos) + 2;
		moveFour.yMoves = parseInt(knight.options.yMoves) + 1;
		moveFour.xMoves = parseInt(knight.options.xMoves) + 2;
		moveFour.totalMoves = knight.options.totalMoves + 1
	fate[3] = moveFour;	
	
	////Below are moves "backward"
	//Moving forward on auto has no use
	//if (!autoTest()){
	
	
		//
		//
		  //
		var moveFive = {};
			moveFive.yPos = parseInt(knight.options.yPos) + 2;
			moveFive.xPos = parseInt(knight.options.xPos) + 1;
			moveFive.xMoves = parseInt(knight.options.xMoves) + 1;
			moveFive.yMoves = parseInt(knight.options.yMoves) + 2;
			moveFive.totalMoves = knight.options.totalMoves + 1
			
		fate[4] = moveFive;
		
		//
		//
	  //
		var moveSix = {};
			moveSix.yPos = parseInt(knight.options.yPos) + 2;
			moveSix.xPos = parseInt(knight.options.xPos) - 1;
			moveSix.xMoves = parseInt(knight.options.xMoves) + 1;
			moveSix.yMoves = parseInt(knight.options.yMoves) + 2;
			moveSix.totalMoves = knight.options.totalMoves + 1
			
		fate[5] = moveSix;
		
		//
		  ////
		var moveSeven = {};
			moveSeven.yPos = parseInt(knight.options.yPos) + 1;
			moveSeven.xPos = parseInt(knight.options.xPos) + 2;
			moveSeven.xMoves = parseInt(knight.options.xMoves) + 2;
			moveSeven.yMoves = parseInt(knight.options.yMoves) + 1;
			moveSeven.totalMoves = knight.options.totalMoves + 1
			
		fate[6] = moveSeven;
		
		//
	////	
		var moveEight = {};
			moveEight.yPos = parseInt(knight.options.yPos) + 1;
			moveEight.xPos = parseInt(knight.options.xPos) - 2;
			moveEight.xMoves = parseInt(knight.options.xMoves) + 2;
			moveEight.yMoves = parseInt(knight.options.yMoves) + 1;
			moveEight.totalMoves = knight.options.totalMoves + 1
			
		fate[7] = moveEight;
		//}
		//alert(knight.options.xPos);
	
	}
	return fate
}

//Lets keep with the fate theme

//Function goal 
//to return the one move (option set object) the knight will make for auto walker
//give it knight on square to test
//give fate
function throwBones(knight) {
	//fate = option sets for each possible move from knights position
	//alert(knight.options.ypos+''+knight.options.xPos);
	fate = decideFate(knight)
	//alert('throwing fates: '+fate.length+' long');
	
	////1
	//alert('Throwing bones on: '+knight.options.yPos+knight.options.xPos);
	
	//loop through fates option set
	for (i=0;i<fate.length;i++){
		//alert(i);
		//alert('running new fate set');
		
		//get square xy of possible move
		
		/////2
		//alert('Testing threads on:'+fate[i].yPos+''+fate[i].xPos);
		
		//pass fate to func 
		//func tests possible moves from position 
		//returns int num of possible moves
		if (readPalms(fate[i])) {
		
			fate[i].threads = castRunes(fate[i])
		}
		
		///////
		////alert(fate[i].threads+' threads on:'+fate[i].yPos+''+fate[i].xPos);
	}
	//Fates options are allowed to extend the board. They are only coord numbers after all
		
	//attach returned possible moves to fate
	
	//loop fates again test which has least possible moves
		//if die rollDice func to determine
	//to hold the best fate
	var minFate = {};
	//minFate.threads
	
	for (i=0;i<fate.length;i++){
		//alert('num '+i);
		//alert('running new fate set');
		//alert('threads: '+fate[i].threads);
		var newFate;
		//if the possible moves from fate[i] are less then the current least thread count
		// OR the current least thread count is undefined  -- init the count
		if (fate[i].threads <= minFate.threads || minFate.threads == undefined){
			
			if (fate[i].threads == 0) {
				//alert('zero square: '+fate[i].yPos+''+fate[i].xPos+'  knight:'+knight.options.yPos+''+knight.options.xPos);
				fate[i].win = 'win';
				return fate[i];
				
			}
			//no zeros  fate[i].threads != 0 &&  was here
			if (fate[i].threads != undefined){
				
				////3
				//alert('smaller fate'+fate[i].yPos+fate[i].xPos+': '+fate[i].threads );
				
				
				//TIE
				if (fate[i].threads == minFate.threads) {
					
					//alert('OMG TIE!')
					//newFate = fate[i];
			
				}
				else {
				
					minFate.threads = fate[i].threads;
					newFate = fate[i];
				}
				
				
				
			}
		}
		
		//get square xy of possible move
		//alert(fate[i].yPos+''+fate[i].xPos);
		
		//pass fate to func 
		//func tests possible moves from position 
		//returns int num of possible moves
		//fate[i].threads = castRunes() 
	}
	////
	//alert('totaled fate  '+minFate.threads);
	//alert('Fate: '+newFate.yPos+''+newFate.xPos);
	
	
	//alert('test read palm: '+readPalms(newFate));
	
	//alert('return: '+readPalms(newFate));
	
	return newFate;
	//return minFate.threads
	
	//return destiny;
}

//return num of possible moves from fate set
function castRunes(fate) {
	
	
	//alert(fate.yPos+' :::::: '+fate.xPos);
	
	//New object holder for fates
	var convert = {};
	convert.options = {};
	convert.options.yPos = fate.yPos;
	convert.options.xPos = fate.xPos;
	//Grab possible moves from fate
	//alert('palms'+readPalms(convert));
	var elem = document.getElementById(String(fate.yPos)+fate.xPos);
	if (!elem) {
		//alert('no id');
		return ;
	};
	
	////3
	//alert('Casting Runes on:'+fate.yPos+fate.xPos );
	
	
	if (elem.toured == true) {
		alert('TOURED');
		return ;
	};
	
	var newFate = decideFate(convert);
	var numFates = 0
	
	for (r=0;r<newFate.length;r++){
		
		//test the square to see if it is viable
		//var palm = readPalms(newFate[r])
		//alert(palm)
		//Check if the item has been toured
		if (readPalms(newFate[r]) == true) {
			//alert('if occupied');
			//alert('if true   :'+readPalms(newFate[r]));
			numFates += 1;
		}
		else {
			//alert('if occupied');
		}
		//alert('fates: '+newFate[r].yPos+newFate[r].xPos);
		
	}
	//func tests possible moves from position 
	//returns int num of possible moves
	
	
	
	//alert(numFates);
	
	////
	//alert(numFates+' option sets from alternate dimension');
	
	////
	//alert('Square ID: '+fate.yPos+fate.xPos+ '   fates='+numFates );
	elem.fates = numFates;
	
	
	//Show fates on board
	////
	elem.innerHTML = 'f'+numFates;
	
	
	//elem.square.options.threads = 'f'+numFates;
	
	
	
	
	//alert(fate.yPos+''+fate.xPos);
	//get matrix box holder (HTML element)
	
	//alert('XYSTIRNIN '+newFate);
	var box = document.getElementById('boardbox');
	
	/*
	//Set our counter to 0
	var threads = 0
	for (l=0; l<box.matrix.length;l++){
		for (ll=0; ll<box.matrix[l].length;ll++) {
			//Add a new div to html
			
			if (box.matrix[l][ll].element.className == 'squareOccupied') {
				threads = threads + 1;
				//alert(box.matrix[i][ii].element.id);
			}
			//box.matrix[i][ii].element.innerHTML
		}
	
	}
	
	
	*/
	return numFates;
	//alert(threads);
	//var knight.options = fate;
	//return knight;
}


//Return true if element is 
function readPalms(options) {
	
	
//Set us up the options
	if (options){
		//alert('good! '+options.yPos+options.xPos);
		var ourPosition = String(options.yPos)+options.xPos;
		//alert('id'+ourPosition);
		var myElement = document.getElementById(ourPosition);
		//alert(myElement);
		
		//Error trap- for off the board items aka squares that don't exist
		if (!myElement){
			//alert('break');
			return false;
		};
		
		/*
		//alert(myElement.id);
		if (myElement.id = 17) {
			alert('17');
			alert('occ '+myElement.occupied);
			alert(myElement.toured);
		}
		*/
		
		
		////
		//alert(myElement.id+' occ: '+myElement.occupied)
		
		//If the element has been visited or is currently occupied
		//if (myElement.occupied == true) {alert('Reading: '+options.yPos+options.xPos);};
		if (myElement.occupied == true || myElement.toured == true) {
			return false;
		}
		else {
			//alert(myElement.id+' toured: '+myElement.toured+'  occ:'+myElement.occupied)
			return true;
		}
		
	}	
	
	

}